const http = require("http");
const fs = require("fs");
const path = require("path");
const { WebSocketServer, WebSocket } = require("ws");

const PORT = process.env.PORT || 3000;
const PUBLIC = path.join(__dirname, "public");
const MAX_PLAYERS = 20;
const WORLD = { width: 2400, height: 1600 };
const TICK_MS = 50;
const players = new Map();
const rooms = new Map();

function roomFor(code) {
  const key = (code || "ILHA").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8) || "ILHA";
  if (!rooms.has(key)) rooms.set(key, { code: key, wood: 0, berries: 0, day: 1, night: false, lastDayChange: Date.now() });
  return rooms.get(key);
}
function send(ws, data) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data));
}
function safeName(value) {
  return String(value || "Sobrevivente").replace(/[<>]/g, "").trim().slice(0, 18) || "Sobrevivente";
}
function clamp(n, lo, hi) { return Math.max(lo, Math.min(hi, n)); }
function publicState(room) {
  return {
    type: "state", room: room.code, world: WORLD,
    resources: { wood: room.wood, berries: room.berries, day: room.day, night: room.night },
    players: [...players.values()].filter(p => p.room === room.code).map(p => ({
      id: p.id, name: p.name, x: p.x, y: p.y, hp: p.hp, hunger: p.hunger,
      wood: p.wood, berries: p.berries, color: p.color
    }))
  };
}

const server = http.createServer((req, res) => {
  let pathname = decodeURIComponent((req.url || "/").split("?")[0]);
  if (pathname === "/") pathname = "/index.html";
  const file = path.normalize(path.join(PUBLIC, pathname));
  if (!file.startsWith(PUBLIC)) { res.writeHead(403); return res.end("Forbidden"); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end("Not found"); }
    const ext = path.extname(file);
    const types = { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "application/javascript; charset=utf-8", ".json": "application/json; charset=utf-8" };
    res.writeHead(200, { "Content-Type": types[ext] || "application/octet-stream", "Cache-Control": "no-store" });
    res.end(data);
  });
});

const wss = new WebSocketServer({ server });
wss.on("connection", (ws) => {
  const id = Math.random().toString(36).slice(2, 10);
  const player = {
    id, ws, room: "ILHA", name: "Sobrevivente", x: 1200 + (Math.random() * 120 - 60),
    y: 800 + (Math.random() * 120 - 60), hp: 100, hunger: 100, wood: 0, berries: 0,
    color: ["#9b8cff", "#62d6a7", "#ffb86b", "#ff7d91", "#7dc8ff"][Math.floor(Math.random() * 5)],
    input: { up: false, down: false, left: false, right: false }
  };
  players.set(id, player);
  send(ws, { type: "welcome", id, room: player.room, maxPlayers: MAX_PLAYERS, world: WORLD });

  ws.on("message", raw => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }
    if (!msg || typeof msg.type !== "string") return;
    if (msg.type === "join") {
      const code = String(msg.room || "ILHA").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8) || "ILHA";
      const count = [...players.values()].filter(p => p.room === code).length;
      if (count > 0 && count >= MAX_PLAYERS) return send(ws, { type: "error", message: "Essa sala já tem 20 jogadores." });
      player.room = code; player.name = safeName(msg.name);
      const room = roomFor(code);
      send(ws, { type: "joined", room: code, id, maxPlayers: MAX_PLAYERS });
      broadcastRoom(room);
    } else if (msg.type === "input") {
      for (const k of ["up", "down", "left", "right"]) player.input[k] = !!msg[k];
    } else if (msg.type === "action") {
      const room = roomFor(player.room);
      if (msg.action === "gather") {
        // Resource points are generated near players, server validates proximity and cooldown.
        const now = Date.now();
        if (now - (player.lastGather || 0) < 650) return;
        player.lastGather = now;
        const roll = Math.random();
        if (roll < 0.55) { player.wood += 1; room.wood += 1; send(ws, { type: "notice", text: "Você coletou 1 madeira." }); }
        else { player.berries += 1; room.berries += 1; send(ws, { type: "notice", text: "Você encontrou 1 fruta." }); }
      } else if (msg.action === "eat") {
        if (player.berries > 0 && player.hunger < 100) {
          player.berries--; player.hunger = Math.min(100, player.hunger + 35);
          send(ws, { type: "notice", text: "Você comeu uma fruta. Fome recuperada!" });
        } else send(ws, { type: "notice", text: player.berries ? "Sua fome já está cheia." : "Você não tem frutas." });
      } else if (msg.action === "campfire") {
        if (player.wood >= 5) {
          player.wood -= 5; room.wood = Math.max(0, room.wood - 5);
          room.night = false; room.day += 1; room.lastDayChange = Date.now();
          for (const p of players.values()) if (p.room === player.room) p.hp = Math.min(100, p.hp + 15);
          send(ws, { type: "notice", text: "Fogueira comunitária acesa! Todos recuperaram vida." });
          broadcastRoom(room);
        } else send(ws, { type: "notice", text: "Você precisa de 5 madeiras para acender a fogueira." });
      }
    }
  });
  ws.on("close", () => { players.delete(id); broadcastRoom(roomFor(player.room)); });
  ws.on("error", () => {});
});

function broadcastRoom(room) {
  const state = JSON.stringify(publicState(room));
  for (const p of players.values()) if (p.room === room.code && p.ws.readyState === WebSocket.OPEN) p.ws.send(state);
}
setInterval(() => {
  const now = Date.now();
  for (const p of players.values()) {
    const speed = 4.2;
    let dx = (p.input.right ? 1 : 0) - (p.input.left ? 1 : 0);
    let dy = (p.input.down ? 1 : 0) - (p.input.up ? 1 : 0);
    if (dx && dy) { dx *= 0.7071; dy *= 0.7071; }
    p.x = clamp(p.x + dx * speed, 22, WORLD.width - 22);
    p.y = clamp(p.y + dy * speed, 22, WORLD.height - 22);
    if (now - (p.lastHungerTick || now) > 12000) {
      p.lastHungerTick = now;
      p.hunger = Math.max(0, p.hunger - 1);
      if (p.hunger === 0) p.hp = Math.max(0, p.hp - 2);
      if (p.hp === 0) { p.hp = 100; p.hunger = 60; p.x = 1200; p.y = 800; }
    }
  }
  for (const room of rooms.values()) broadcastRoom(room);
}, TICK_MS);

server.listen(PORT, "0.0.0.0", () => console.log(`Ilha Coop rodando na porta ${PORT}`));