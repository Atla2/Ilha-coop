(() => {
  const canvas = document.getElementById("game"), ctx = canvas.getContext("2d");
  const $ = id => document.getElementById(id);
  let ws, myId = null, room = "ILHA", world = {width:2400,height:1600}, state = null;
  let camera = {x:0,y:0}, held = {up:false,down:false,left:false,right:false}, noticeTimer;
  const trees = [], bushes = [], rocks = [];
  // Deterministic-looking decorative resources, rendered locally.
  for (let i=0;i<125;i++) {
    const x = 80 + ((i*197 + (i%7)*83) % 2240), y = 80 + ((i*131 + (i%11)*47) % 1440);
    if (i%3===0) rocks.push({x,y,r:8+(i%5)});
    else if (i%4===0) bushes.push({x,y,r:10+(i%5)});
    else trees.push({x,y,r:14+(i%10)});
  }
  function resize(){const dpr=Math.min(devicePixelRatio||1,2);canvas.width=Math.floor(canvas.clientWidth*dpr);canvas.height=Math.floor(canvas.clientHeight*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);}
  window.addEventListener("resize",resize); resize();
  function send(obj){if(ws && ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify(obj));}
  function showNotice(text){$("notice").textContent=text;$("notice").classList.add("show");clearTimeout(noticeTimer);noticeTimer=setTimeout(()=>$("notice").classList.remove("show"),2200);}
  function connect(){
    const proto=location.protocol==="https:"?"wss:":"ws:";
    ws=new WebSocket(`${proto}//${location.host}`);
    $("connection").textContent="Conectando…";
    ws.onopen=()=>{$("connection").textContent="● Online";send({type:"join",name:$("nameInput").value,room:$("roomInput").value});};
    ws.onclose=()=>{$("connection").textContent="Desconectado";setTimeout(()=>{if(!$("joinScreen").classList.contains("hidden"))return;connect();},2000);};
    ws.onerror=()=>{$("connection").textContent="Erro de conexão";};
    ws.onmessage=e=>{let m;try{m=JSON.parse(e.data)}catch{return}
      if(m.type==="welcome"){myId=m.id;world=m.world||world;}
      if(m.type==="joined"){room=m.room;$("roomBadge").textContent="Sala: "+room;$("joinScreen").classList.add("hidden");}
      if(m.type==="error"){$("joinError").textContent=m.message;showNotice(m.message);}
      if(m.type==="state"){state=m;updateHud();}
      if(m.type==="notice")showNotice(m.text);
    };
  }
  $("joinBtn").addEventListener("click",()=>{if(ws && ws.readyState===WebSocket.OPEN){$("joinError").textContent="";send({type:"join",name:$("nameInput").value,room:$("roomInput").value});}else connect();});
  function updateHud(){
    if(!state)return;const me=state.players.find(p=>p.id===myId);if(!me)return;
    $("hp").textContent=me.hp;$("hpBar").style.width=me.hp+"%";$("hunger").textContent=me.hunger;$("hungerBar").style.width=me.hunger+"%";
    $("wood").textContent=me.wood;$("berries").textContent=me.berries;$("day").textContent=state.resources.day;
    $("playersCount").textContent=state.players.length+" jogador"+(state.players.length===1?"":"es");
  }
  function inputSend(){send({type:"input",...held});}
  document.querySelectorAll("[data-dir]").forEach(btn=>{
    const dir=btn.dataset.dir;
    const down=e=>{e.preventDefault();held[dir]=true;btn.classList.add("active");inputSend();};
    const up=e=>{e.preventDefault();held[dir]=false;btn.classList.remove("active");inputSend();};
    btn.addEventListener("pointerdown",down);btn.addEventListener("pointerup",up);btn.addEventListener("pointercancel",up);btn.addEventListener("pointerleave",e=>{if(e.buttons)up(e);});
  });
  window.addEventListener("keydown",e=>{const map={ArrowUp:"up",w:"up",ArrowDown:"down",s:"down",ArrowLeft:"left",a:"left",ArrowRight:"right",d:"right"};const k=map[e.key];if(k){held[k]=true;inputSend();}});
  window.addEventListener("keyup",e=>{const map={ArrowUp:"up",w:"up",ArrowDown:"down",s:"down",ArrowLeft:"left",a:"left",ArrowRight:"right",d:"right"};const k=map[e.key];if(k){held[k]=false;inputSend();}});
  $("gatherBtn").onclick=()=>send({type:"action",action:"gather"});
  $("eatBtn").onclick=()=>send({type:"action",action:"eat"});
  $("campBtn").onclick=()=>send({type:"action",action:"campfire"});
  function circle(x,y,r,fill,stroke){ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=2;ctx.stroke();}}
  function draw(){
    requestAnimationFrame(draw);
    const w=canvas.clientWidth,h=canvas.clientHeight;
    ctx.clearRect(0,0,w,h);
    ctx.fillStyle="#25483b";ctx.fillRect(0,0,w,h);
    if(!state){ctx.fillStyle="#d4e8dc";ctx.font="14px system-ui";ctx.fillText("Conectando à ilha…",20,40);return;}
    const me=state.players.find(p=>p.id===myId);
    if(me){camera.x=Math.max(0,Math.min(world.width-w,me.x-w/2));camera.y=Math.max(0,Math.min(world.height-h,me.y-h/2));}
    ctx.save();ctx.translate(-camera.x,-camera.y);
    // Ground patches
    for(let i=0;i<90;i++){const x=(i*281)%world.width,y=(i*173)%world.height;ctx.fillStyle=i%2?"#2a503f":"#2b4d3e";ctx.beginPath();ctx.ellipse(x,y,35+(i%5)*8,17+(i%4)*6,i%3,0,Math.PI*2);ctx.fill();}
    // Beach border
    ctx.strokeStyle="#8bbd91";ctx.lineWidth=18;ctx.strokeRect(10,10,world.width-20,world.height-20);
    trees.forEach(t=>{circle(t.x,t.y+5,t.r*.75,"#173a2c");circle(t.x,t.y,t.r,"#34724a","#245539");circle(t.x-t.r*.25,t.y-t.r*.25,t.r*.32,"#4d8d5a");});
    bushes.forEach(b=>{circle(b.x,b.y,b.r,"#648b48","#41653b");circle(b.x-3,b.y-3,3,"#d76d78");circle(b.x+4,b.y+2,3,"#d76d78");});
    rocks.forEach(r=>{circle(r.x,r.y,r.r,"#78867d","#56645d");circle(r.x-3,r.y-3,r.r*.35,"#9aa79c");});
    // Community camp
    circle(1200,800,45,"#18372e","#d6b97a");circle(1200,800,28,"#6a4d32");circle(1200,800,16,"#f6a34b");circle(1195,795,7,"#ffe08a");
    ctx.fillStyle="#f7e3aa";ctx.font="12px system-ui";ctx.textAlign="center";ctx.fillText("FOGUEIRA",1200,750);
    for(const p of state.players){
      circle(p.x,p.y+8,12,"#142a22aa");
      circle(p.x,p.y,12,p.color,"#e5f6e9");
      circle(p.x-3,p.y-3,3,"#fff");
      ctx.fillStyle="#f4f8f4";ctx.font="12px system-ui";ctx.textAlign="center";ctx.fillText(p.name+(p.id===myId?" (você)":""),p.x,p.y-20);
      ctx.fillStyle="#27332c";ctx.fillRect(p.x-13,p.y+16,26,4);ctx.fillStyle="#79e2a0";ctx.fillRect(p.x-13,p.y+16,26*p.hp/100,4);
    }
    ctx.restore();
    // Soft dark edge overlay
    const grad=ctx.createRadialGradient(w/2,h/2,Math.min(w,h)*.25,w/2,h/2,Math.max(w,h)*.7);grad.addColorStop(0,"#00000000");grad.addColorStop(1,"#08141035");ctx.fillStyle=grad;ctx.fillRect(0,0,w,h);
  }
  connect();draw();
})();