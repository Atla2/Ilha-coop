# Ilha Coop — sobrevivência multiplayer 2D

Protótipo funcional de jogo cooperativo para navegador de celular, com servidor autoritativo Node.js + WebSocket.

## O que já está implementado

- Canvas 2D com mapa de ilha e câmera que acompanha o jogador.
- Controles de toque (direcional) e teclado.
- Salas por código; até 20 jogadores por sala.
- Sincronização em tempo real via WebSocket.
- Vida e fome; fome diminui com o tempo e pode causar dano.
- Ações de coletar madeira/frutas, comer e acender fogueira comunitária.
- Estado de recursos e jogadores processado pelo servidor.
- Reconexão simples após desconexão.

## Limitações do protótipo

- A coleta atualmente entrega um recurso aleatório, não verifica árvores/bosques próximos.
- Não há monstros, inventário persistente, contas, chat, construção de estruturas ou salvamento entre reinicializações.
- Não há proteção robusta contra trapaças, limitação de taxa, banco de dados ou moderação de nomes.
- A capacidade real de 20 jogadores depende dos recursos e da rede do host; foi definida como limite por sala, mas precisa de teste de carga antes de divulgar publicamente.
- Não existe servidor público criado por este pacote. A hospedagem externa precisa ser configurada pelo proprietário.

## Executar no computador

Requer Node.js 18 ou superior.

```bash
npm install
npm start
```

Abra `http://localhost:3000`.

Para testar com outras pessoas na mesma rede Wi-Fi, descubra o IP local do computador e abra `http://IP-DO-COMPUTADOR:3000` no celular. O firewall precisa permitir a porta 3000.

## Hospedagem gratuita (opção de baixo custo)

A aplicação precisa de um host Node.js que mantenha conexões WebSocket. Um host estático, sozinho, não hospeda o servidor.

1. Crie um repositório GitHub e envie todos os arquivos deste projeto.
2. Escolha um provedor que suporte aplicações Node.js e WebSocket (por exemplo, Render ou Railway; confira os limites e a política gratuita vigentes antes de implantar).
3. Crie um serviço web ligado ao repositório.
4. Build command: `npm install`
5. Start command: `npm start`
6. Configure a variável `PORT` se o provedor exigir; o servidor usa `process.env.PORT`.
7. Após a implantação, abra a URL HTTPS fornecida. O cliente seleciona `wss://` automaticamente em HTTPS.
8. Teste em dois celulares/navegadores e, depois, teste com mais conexões.

**Atenção:** planos gratuitos podem dormir após inatividade, limitar horas, largura de banda ou conexões e mudar suas regras. Verifique a oferta atual do provedor. Para uma sala pública com 20 pessoas, monitore memória, CPU e estabilidade. O servidor envia o estado a cada 50 ms; se isso for pesado no host, reduza a frequência de atualização antes de aumentar a população.

## Desenvolver pelo celular

- É possível editar os arquivos com um editor de código móvel ou no editor web do GitHub.
- Para hospedar sem computador, envie os arquivos ao GitHub e faça o deploy pelo painel web do provedor.
- Um terminal Node.js local no celular não é necessário se a compilação e a execução forem feitas na hospedagem.

## Estrutura

```text
ilha-coop/
├── package.json
├── server.js
├── README.md
└── public/
    ├── index.html
    ├── style.css
    └── game.js
```

## Próximas melhorias recomendadas

1. Validar a coleta por proximidade de recursos reais no servidor.
2. Adicionar ciclo de dia/noite, inimigos e dano de combate.
3. Adicionar chat e código de convite.
4. Adicionar limites por IP e validação de mensagens.
5. Persistir progresso em banco de dados.
6. Fazer testes de carga e segurança antes de abrir ao público.
