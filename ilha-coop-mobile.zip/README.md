# Ilha Coop — protótipo multiplayer v2

Protótipo 2D de sobrevivência cooperativa multiplayer para navegador (mobile-friendly).

## Novidades desta versão

- **Persistência de ranking** — pontos e estrelas salvos em arquivo JSON por nome de jogador
- **Armas**: mão, faca, espada, arco, machado (drop de monstros e coleta)
- **Construções**: Abrigo e Muro (reduzem dano recebido)
- **Monstros**: zumbi, besta e esqueleto com IA básica
- **Proteção de spawn** (alguns segundos após nascer/respawnar)
- **Rate limiting** mais forte contra spam de ações
- Conta de desenvolvedor com selo ✓ e +60% de pontos
- Ciclo dia/noite, chat, Olho do Caçador, modos Ranqueado/Clássico/4x4

## Como executar

```bash
npm install
npm start
```

Abra `http://localhost:3000`

## Conta de desenvolvedor
Use nome contendo: `wesley`, `wntt`, `atlas_dev` ou `dev_wesley`

## Controles
- D-pad / WASD / setas — movimento
- C — agachar
- Botões na tela — coletar, comer, fogueira, construir, atacar, habilidade, olho

## Ainda futuro
- Contas com senha / banco real
- Chat por voz
- Editor de HUD
- Mais conteúdo e balanceamento
