const http = require("http");
const fs = require("fs");
const path = require("path");
const { WebSocketServer, WebSocket } = require("ws");

const PORT = process.env.PORT || 3000;
const PUBLIC = path.join(__dirname, "public");
const DATA_DIR = path.join(__dirname, "data");
const PLAYERS_FILE = path.join(DATA_DIR, "players.json");
const MAX_PLAYERS = 20;
const WORLD = { width: 3200, height: 2200 };
const CITIES = [
  { name: "Atlas", x: 1600, y: 1100, radius: 390, type: "capital" },
  { name: "Poseidon", x: 520, y: 500, radius: 250, type: "coastal" },
  { name: "Atena", x: 2650, y: 480, radius: 250, type: "knowledge" },
  { name: "Ares", x: 500, y: 1740, radius: 250, type: "fortress" },
  { name: "Ártemis", x: 2700, y: 1720, radius: 250, type: "forest" },
  { name: "Hefesto", x: 1600, y: 300, radius: 220, type: "forge" }
];
const MODES = {
  ranked: { label: "Ranqueado", maxPlayers: 20, teamSize: 4 },
  classic: { label: "Clássico", maxPlayers: 20, teamSize: 4 },
  arena4v4: { label: "4x4", maxPlayers: 8, teamSize: 4, smallMap: true }
};
const TICK_MS = 50;
const RACES = ["Humano", "Elfo", "Fada", "Duende", "Anão", "Elfo Negro"];
const CLASSES = ["Guerreiro", "Mago", "Curandeiro", "Arqueiro", "Assassino", "Druida"];
const ARENA_RANKS = [
  "Bronze I","Bronze II","Bronze III",
  "Prata I","Prata II","Prata III","Prata IV",
  "Ouro I","Ouro II","Ouro III","Ouro IV",
  ...Array.from({ length: 10 }, (_, i) => `Safira ${["I","II","III","IV","V","VI","VII","VIII","IX","X"][i]}`),
  "Rei"
];
const RACE_WEAKNESS = {
  Humano: "Elfo", Elfo: "Duende", Duende: "Fada",
  Fada: "Elfo Negro", "Elfo Negro": "Anão", Anão: "Humano"
};
// Apenas o nick exato "Atlas_dev" (sem diferenciar maiúsculas) é conta de desenvolvedor
const DEV_NICK = "atlas_dev";
const WEAPONS = {
  mão: { damage: 0, range: 0 },
  faca: { damage: 4, range: 40 },
  espada: { damage: 10, range: 55 },
  arco: { damage: 7, range: 35, range: 90 },
  machado: { damage: 12, range: 45 }
};

// ---------- Persistência simples ----------
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
let savedPlayers = {};
try {
  if (fs.existsSync(PLAYERS_FILE)) {
    savedPlayers = JSON.parse(fs.readFileSync(PLAYERS_FILE, "utf8") || "{}");
  }
} catch { savedPlayers = {}; }

function savePlayers() {
  try {
    fs.writeFileSync(PLAYERS_FILE, JSON.stringify(savedPlayers, null, 2));
  } catch (e) {
    console.error("Erro ao salvar players:", e.message);
  }
}
function playerKey(name) {
  return String(name || "").toLowerCase().trim().slice(0, 24);
}
function loadProgress(name) {
  const key = playerKey(name);
  return savedPlayers[key] || { rankedPoints: 0, arenaStarsTotal: 0, wins: 0, kills: 0 };
}
function persistProgress(player) {
  if (!player || !player.name) return;
  const key = playerKey(player.name);
  savedPlayers[key] = {
    rankedPoints: player.rankedPoints || 0,
    arenaStarsTotal: player.arenaStarsTotal || 0,
    wins: (savedPlayers[key]?.wins || 0) + (player._winInc || 0),
    kills: (savedPlayers[key]?.kills || 0) + (player._killInc || 0),
    lastSeen: Date.now(),
    isDev: player.isDev || false
  };
  player._winInc = 0;
  player._killInc = 0;
  savePlayers();
}

const players = new Map();
const rooms = new Map();

function isDeveloper(name) {
  // Somente o nick Atlas_dev recebe benefícios de desenvolvedor
  return playerKey(name) === DEV_NICK;
}

function roomFor(code, mode = "classic") {
  const roomCode = (code || "ILHA").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8) || "ILHA";
  const safeMode = MODES[mode] ? mode : "classic";
  const key = `${safeMode}:${roomCode}`;
  if (!rooms.has(key)) {
    rooms.set(key, {
      key, code: roomCode, mode: safeMode,
      wood: 0, berries: 0, day: 1, night: false, lastDayChange: Date.now(),
      teamSpawns: new Map(), spawnCounts: new Map(), nextTeamId: 0,
      hunterItems: [
        { x: 360, y: 360, taken: false },
        { x: 2800, y: 360, taken: false },
        { x: 420, y: 1840, taken: false },
        { x: 2780, y: 1840, taken: false },
        { x: 1600, y: 300, taken: false },
        { x: 1600, y: 1850, taken: false }
      ],
      round: 1, roundEnding: false,
      buildings: [],
      monsters: [],
      lastMonsterSpawn: Date.now(),
      createdAt: Date.now()
    });
  }
  return rooms.get(key);
}

function pickSpawn(room, teamId) {
  const mode = MODES[room.mode];
  if (mode.smallMap) {
    const arena = [{ x: 260, y: 450 }, { x: 940, y: 450 }];
    const side = teamId % 2;
    const offset = Math.floor(teamId / 2) * 30;
    const chosen = { city: "Arena 4x4", x: arena[side].x + (side ? -offset : offset), y: arena[side].y + offset };
    room.teamSpawns.set(teamId, chosen);
    return chosen;
  }
  const candidates = CITIES.map((city, index) => {
    const count = room.spawnCounts.get(city.name) || 0;
    const angle = ((teamId * 2.3999632297 + index * 1.7) % (Math.PI * 2));
    const spread = Math.min(city.radius * 0.62, 95 + count * 28);
    const x = city.x + Math.cos(angle) * spread;
    const y = city.y + Math.sin(angle) * spread;
    let nearest = Infinity;
    for (const pos of room.teamSpawns.values()) nearest = Math.min(nearest, Math.hypot(x - pos.x, y - pos.y));
    const distanceScore = Number.isFinite(nearest) ? Math.min(nearest, 1800) : 1800;
    const score = distanceScore - count * 950 + (city.type === "capital" ? -180 : 0) + Math.random() * 90;
    return { city, x, y, score };
  });
  candidates.sort((a, b) => b.score - a.score);
  const chosen = candidates[0];
  room.spawnCounts.set(chosen.city.name, (room.spawnCounts.get(chosen.city.name) || 0) + 1);
  room.teamSpawns.set(teamId, { x: chosen.x, y: chosen.y, city: chosen.city.name });
  return { city: chosen.city.name, x: chosen.x, y: chosen.y };
}

function rankedRank(points) {
  const roman = ["I","II","III","IV","V","VI","VII","VIII","IX","X"];
  if (points >= 5000) return "Rei";
  if (points >= 900) return `Safira ${roman[Math.min(9, Math.floor((points - 900) / 410))]}`;
  if (points >= 400) return `Ouro ${roman[Math.min(3, Math.floor((points - 400) / 125))]}`;
  if (points >= 100) return `Prata ${roman[Math.min(3, Math.floor((points - 100) / 75))]}`;
  return `Bronze ${roman[Math.min(2, Math.floor(points / 34))]}`;
}

function rankedKillReward(points, isDev) {
  let base = points < 100 ? 30 : points < 400 ? 25 : points < 900 ? 20 : points < 2500 ? 15 : 10;
  if (isDev) base = Math.ceil(base * 1.6);
  return base;
}

function rankForStars(stars) {
  let remaining = Math.max(0, stars);
  let index = 0;
  while (index < ARENA_RANKS.length - 1 && remaining >= 3) {
    remaining -= 3;
    index++;
  }
  return { rank: ARENA_RANKS[index], stars: remaining, rankIndex: index };
}

function teamAlive(room, teamId) {
  return [...players.values()].some(p => p.room === room.key && p.teamId === teamId && !p.eliminated);
}

function checkArenaRound(room) {
  if (room.mode !== "arena4v4" || room.roundEnding) return;
  const teams = [...new Set([...players.values()].filter(p => p.room === room.key).map(p => p.teamId))];
  if (teams.length < 2) return;
  const alive = teams.filter(t => teamAlive(room, t));
  if (alive.length !== 1) return;
  room.roundEnding = true;
  const winner = alive[0];
  for (const p of players.values()) {
    if (p.room !== room.key) continue;
    if (p.teamId === winner) {
      p.arenaStarsTotal += 1;
      p._winInc = (p._winInc || 0) + 1;
      const r = rankForStars(p.arenaStarsTotal);
      p.arenaRank = r.rank;
      p.arenaStars = r.stars;
      persistProgress(p);
      send(p.ws, { type: "notice", text: `Vitória no 4x4! +1 estrela. Patente: ${p.arenaRank} (${p.arenaStars}★)` });
    } else {
      send(p.ws, { type: "notice", text: "Sua equipe perdeu a rodada. Tente novamente!" });
    }
  }
  setTimeout(() => {
    for (const p of players.values()) {
      if (p.room !== room.key) continue;
      p.hp = 200;
      p.eliminated = false;
      p.spawnProtectUntil = Date.now() + 3000;
      const sp = room.teamSpawns.get(p.teamId);
      if (sp) {
        p.x = sp.x + (Math.random() - 0.5) * 60;
        p.y = sp.y + (Math.random() - 0.5) * 60;
        p.city = sp.city;
      }
    }
    room.round++;
    room.roundEnding = false;
    room.monsters = [];
    // Reset hunter items for new round in other modes is not needed here
    broadcastRoom(room);
  }, 3500);
}

function send(ws, data) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data));
}

function safeName(value) {
  return String(value || "Sobrevivente").replace(/[<>]/g, "").trim().slice(0, 18) || "Sobrevivente";
}

function clamp(n, lo, hi) {
  return Math.max(lo, Math.min(hi, n));
}

function rateLimit(player, key, ms) {
  const now = Date.now();
  const last = player.rateLimits?.[key] || 0;
  if (now - last < ms) return false;
  if (!player.rateLimits) player.rateLimits = {};
  player.rateLimits[key] = now;
  return true;
}

function spawnMonster(room) {
  if (room.mode === "arena4v4") return;
  if (room.monsters.length >= 20) return;
  const city = CITIES[Math.floor(Math.random() * CITIES.length)];
  const angle = Math.random() * Math.PI * 2;
  const dist = 90 + Math.random() * (city.radius * 0.75);
  const types = ["zumbi", "zumbi", "besta", "esqueleto"];
  const type = types[Math.floor(Math.random() * types.length)];
  const hpMap = { zumbi: 50, besta: 70, esqueleto: 40 };
  room.monsters.push({
    id: Math.random().toString(36).slice(2, 8),
    x: city.x + Math.cos(angle) * dist,
    y: city.y + Math.sin(angle) * dist,
    hp: hpMap[type] || 50,
    maxHp: hpMap[type] || 50,
    type,
    lastAttack: 0
  });
}

function publicState(room) {
  return {
    type: "state",
    room: room.code,
    mode: room.mode,
    modeLabel: MODES[room.mode].label,
    world: room.mode === "arena4v4" ? { width: 1200, height: 900, smallMap: true } : WORLD,
    cities: room.mode === "arena4v4" ? [] : CITIES,
    resources: { wood: room.wood, berries: room.berries, day: room.day, night: room.night },
    hunterItems: room.mode === "arena4v4" ? [] : room.hunterItems.filter(i => !i.taken),
    buildings: room.buildings || [],
    monsters: (room.monsters || []).map(m => ({
      id: m.id, x: m.x, y: m.y, hp: m.hp, maxHp: m.maxHp, type: m.type
    })),
    round: room.round,
    players: [...players.values()].filter(p => p.room === room.key).map(p => ({
      id: p.id,
      name: p.name,
      x: p.x,
      y: p.y,
      hp: p.hp,
      hunger: p.hunger,
      wood: p.wood,
      berries: p.berries,
      color: p.color,
      teamId: p.teamId,
      city: p.city,
      rankedPoints: p.rankedPoints,
      rankedRank: rankedRank(p.rankedPoints),
      arenaStars: p.arenaStars,
      arenaRank: p.arenaRank,
      ep: p.ep,
      race: p.race,
      playerClass: p.playerClass,
      crouching: p.crouching,
      eliminated: p.eliminated,
      hasHunterDevice: p.hunterDevices > 0,
      hunterDevices: p.hunterDevices,
      isVerified: p.isVerified,
      isDev: p.isDev,
      weapon: p.weapon || "mão",
      spawnProtect: p.spawnProtectUntil && p.spawnProtectUntil > Date.now()
    }))
  };
}

const server = http.createServer((req, res) => {
  let pathname = decodeURIComponent((req.url || "/").split("?")[0]);
  if (pathname === "/") pathname = "/index.html";
  const file = path.normalize(path.join(PUBLIC, pathname));
  if (!file.startsWith(PUBLIC)) {
    res.writeHead(403);
    return res.end("Forbidden");
  }
  fs.readFile(file, (err, data) => {
    if (err) {
      res.writeHead(404);
      return res.end("Not found");
    }
    const ext = path.extname(file);
    const types = {
      ".html": "text/html; charset=utf-8",
      ".css": "text/css; charset=utf-8",
      ".js": "application/javascript; charset=utf-8",
      ".json": "application/json; charset=utf-8"
    };
    res.writeHead(200, {
      "Content-Type": types[ext] || "application/octet-stream",
      "Cache-Control": "no-store"
    });
    res.end(data);
  });
});

const wss = new WebSocketServer({ server });

wss.on("connection", (ws) => {
  const id = Math.random().toString(36).slice(2, 10);
  const player = {
    id, ws, room: null, mode: "classic", teamId: 0, city: "Atlas",
    name: "Sobrevivente", x: 1600, y: 1100,
    hp: 200, ep: 200, hunger: 100, wood: 0, berries: 0,
    rankedPoints: 0, arenaStars: 0, arenaStarsTotal: 0, arenaRank: "Bronze I",
    race: "Humano", playerClass: "Guerreiro",
    crouching: false, eliminated: false,
    hunterDevices: 0, isVerified: false, isDev: false,
    weapon: "mão",
    spawnProtectUntil: 0,
    rateLimits: {},
    _winInc: 0, _killInc: 0,
    color: ["#9b8cff", "#62d6a7", "#ffb86b", "#ff7d91", "#7dc8ff"][Math.floor(Math.random() * 5)],
    input: { up: false, down: false, left: false, right: false }
  };
  players.set(id, player);

  send(ws, {
    type: "welcome",
    id,
    room: "ILHA",
    maxPlayers: MAX_PLAYERS,
    world: WORLD,
    modes: MODES,
    races: RACES,
    classes: CLASSES
  });

  ws.on("message", raw => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }
    if (!msg || typeof msg.type !== "string") return;

    // Rate limit genérico de mensagens
    if (!rateLimit(player, "msg", 40)) return;

    if (msg.type === "join") {
      const code = String(msg.room || "ILHA").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8) || "ILHA";
      const mode = MODES[msg.mode] ? msg.mode : "classic";
      const room = roomFor(code, mode);
      const desiredName = safeName(msg.name);

      // Impede nicks vazios ou muito curtos
      if (!desiredName || desiredName.length < 2) {
        return send(ws, { type: "error", message: "Escolha um nick com pelo menos 2 caracteres." });
      }

      // Impede nicks repetidos (online, sem diferenciar maiúsculas/minúsculas)
      const nameTaken = [...players.values()].some(p =>
        p.id !== id &&
        p.room && // só quem já entrou em alguma sala
        playerKey(p.name) === playerKey(desiredName)
      );
      if (nameTaken) {
        return send(ws, {
          type: "error",
          message: `O nick "${desiredName}" já está em uso. Escolha outro nome.`
        });
      }

      const current = [...players.values()].filter(p => p.id !== id && p.room === room.key);
      const limit = MODES[mode].maxPlayers;
      if (current.length >= limit) {
        return send(ws, { type: "error", message: `Sala cheia no modo ${MODES[mode].label} (máx ${limit}).` });
      }

      const teamSize = MODES[mode].teamSize;
      const teamCounts = new Map();
      current.forEach(p => teamCounts.set(p.teamId, (teamCounts.get(p.teamId) || 0) + 1));
      let teamId = 0;
      while ((teamCounts.get(teamId) || 0) >= teamSize) teamId++;
      if (!room.teamSpawns.has(teamId)) pickSpawn(room, teamId);
      const spawn = room.teamSpawns.get(teamId);
      const teamSlot = teamCounts.get(teamId) || 0;

      player.room = room.key;
      player.mode = mode;
      player.name = desiredName;
      player.teamId = teamId;
      player.race = RACES.includes(msg.race) ? msg.race : "Humano";
      player.playerClass = CLASSES.includes(msg.playerClass) ? msg.playerClass : "Guerreiro";
      player.city = spawn.city;
      player.x = spawn.x + (teamSlot - (teamSize - 1) / 2) * 24;
      player.y = spawn.y + (teamSlot % 2 ? 20 : -20);
      player.eliminated = false;
      player.hunterDevices = 0;
      player.weapon = "mão";
      player.spawnProtectUntil = Date.now() + 4000;
      player.hp = 200;
      player.ep = 200;
      player.hunger = 100;
      player.wood = 0;
      player.berries = 0;

      // Carrega progresso salvo
      const prog = loadProgress(player.name);
      player.rankedPoints = prog.rankedPoints || 0;
      player.arenaStarsTotal = prog.arenaStarsTotal || 0;
      const r = rankForStars(player.arenaStarsTotal);
      player.arenaRank = r.rank;
      player.arenaStars = r.stars;

      player.isDev = isDeveloper(player.name);
      player.isVerified = player.isDev;
      if (player.isDev) {
        player.rankedPoints = Math.max(player.rankedPoints, 50);
        send(ws, { type: "notice", text: "Conta de Desenvolvedor reconhecida! ✓ Selo + bônus de pontos ativos." });
      }

      send(ws, {
        type: "joined",
        room: code,
        mode,
        modeLabel: MODES[mode].label,
        city: player.city,
        teamId,
        id,
        maxPlayers: limit,
        race: player.race,
        playerClass: player.playerClass,
        isVerified: player.isVerified,
        isDev: player.isDev,
        rankedPoints: player.rankedPoints,
        rankedRank: rankedRank(player.rankedPoints),
        arenaRank: player.arenaRank,
        arenaStars: player.arenaStars
      });
      broadcastRoom(room);
    }

    else if (msg.type === "input") {
      if (!rateLimit(player, "input", 30)) return;
      for (const k of ["up", "down", "left", "right"]) player.input[k] = !!msg[k];
      player.crouching = !!msg.crouching;
    }

    else if (msg.type === "chat") {
      if (!player.room) return;
      if (!rateLimit(player, "chat", 900)) return;
      const text = String(msg.text || "").replace(/[<>]/g, "").trim().slice(0, 180);
      if (!text) return;
      const room = rooms.get(player.room);
      if (!room) return;
      const channel = msg.channel === "team" ? "team" : "global";
      for (const target of players.values()) {
        if (target.room === player.room && (channel === "global" || target.teamId === player.teamId)) {
          send(target.ws, {
            type: "chat",
            channel,
            from: player.name,
            teamId: player.teamId,
            text,
            isVerified: player.isVerified
          });
        }
      }
    }

    else if (msg.type === "action") {
      const room = rooms.get(player.room);
      if (!room) return;
      if (player.eliminated) return send(ws, { type: "notice", text: "Você foi eliminado desta rodada." });
      if (!rateLimit(player, "action", 120)) return;

      if (msg.action === "attack") {
        if (!rateLimit(player, "attack", 600)) return;
        const now = Date.now();

        // Proteção de spawn
        if (player.spawnProtectUntil > now) {
          return send(ws, { type: "notice", text: "Proteção de spawn ativa. Aguarde um pouco." });
        }

        // Atacar monstro
        let nearestMonster = null;
        let nearestDist = 80;
        for (const m of room.monsters) {
          const d = Math.hypot(m.x - player.x, m.y - player.y);
          if (d < nearestDist) {
            nearestDist = d;
            nearestMonster = m;
          }
        }
        if (nearestMonster) {
          const wpn = WEAPONS[player.weapon] || WEAPONS.mão;
          let damage = (player.playerClass === "Guerreiro" ? 30 : player.playerClass === "Assassino" ? 26 : 22) + wpn.damage;
          nearestMonster.hp -= damage;
          send(ws, { type: "notice", text: `Você acertou o ${nearestMonster.type} (${damage} de dano).` });
          if (nearestMonster.hp <= 0) {
            room.monsters = room.monsters.filter(m => m.id !== nearestMonster.id);
            player.wood += 1 + (Math.random() < 0.3 ? 1 : 0);
            if (Math.random() < 0.45) player.berries += 1;
            // Chance de dropar arma
            if (Math.random() < 0.12 && player.weapon === "mão") {
              const drops = ["faca", "espada", "arco", "machado"];
              player.weapon = drops[Math.floor(Math.random() * drops.length)];
              send(ws, { type: "notice", text: `O ${nearestMonster.type} dropou uma ${player.weapon}!` });
            }
            if (room.mode === "ranked") {
              const reward = Math.ceil(rankedKillReward(player.rankedPoints, player.isDev) * 0.35);
              player.rankedPoints += reward;
              persistProgress(player);
              send(ws, { type: "notice", text: `${nearestMonster.type} eliminado! +${reward} pts.` });
            } else {
              send(ws, { type: "notice", text: `${nearestMonster.type} eliminado! Recursos coletados.` });
            }
          }
          broadcastRoom(room);
          return;
        }

        // Atacar jogador
        let targets = [...players.values()].filter(t =>
          t.room === player.room && t.id !== player.id && t.teamId !== player.teamId &&
          !t.eliminated && Math.hypot(t.x - player.x, t.y - player.y) < 78 &&
          !(t.spawnProtectUntil > now)
        );
        targets.sort((a, b) => Math.hypot(a.x - player.x, a.y - player.y) - Math.hypot(b.x - player.x, b.y - player.y));
        const target = targets[0];
        if (!target) return send(ws, { type: "notice", text: "Nenhum inimigo ao alcance." });

        const wpn = WEAPONS[player.weapon] || WEAPONS.mão;
        let damage = (player.playerClass === "Guerreiro" ? 28 : player.playerClass === "Assassino" ? 25 : player.playerClass === "Arqueiro" ? 24 : 22) + wpn.damage;
        if (player.skillBoostUntil && player.skillBoostUntil > now) damage += 10;
        if (RACE_WEAKNESS[player.race] === target.race) damage += 8;
        if (target.crouching && target.playerClass === "Guerreiro") damage = Math.ceil(damage * 0.6);
        // Abrigo reduz dano
        const nearBuilding = (room.buildings || []).some(b =>
          b.teamId === target.teamId && Math.hypot(b.x - target.x, b.y - target.y) < 70
        );
        if (nearBuilding) damage = Math.ceil(damage * 0.65);

        target.hp = Math.max(0, target.hp - damage);
        send(ws, { type: "notice", text: `Você acertou ${target.name} (${damage} de dano).` });

        if (target.hp <= 0) {
          player._killInc = (player._killInc || 0) + 1;
          if (room.mode === "arena4v4") {
            target.eliminated = true;
            target.input = { up: false, down: false, left: false, right: false };
          } else {
            target.hp = 200;
            target.spawnProtectUntil = Date.now() + 3500;
            const sp = room.teamSpawns.get(target.teamId) || { x: 1600, y: 1100 };
            target.x = sp.x;
            target.y = sp.y;
          }
          const reward = room.mode === "ranked" ? rankedKillReward(player.rankedPoints, player.isDev) : 0;
          if (room.mode === "ranked") {
            player.rankedPoints += reward;
            target.rankedPoints = Math.max(0, target.rankedPoints - 5);
            persistProgress(player);
            persistProgress(target);
          }
          if (target.hunterDevices > 0) {
            player.hunterDevices += target.hunterDevices;
            target.hunterDevices = 0;
            send(player.ws, { type: "notice", text: "Você saqueou o Olho do Caçador!" });
          }
          // Chance de roubar arma
          if (target.weapon && target.weapon !== "mão" && Math.random() < 0.35) {
            const stolen = target.weapon;
            target.weapon = "mão";
            if (player.weapon === "mão" || WEAPONS[stolen].damage > (WEAPONS[player.weapon]?.damage || 0)) {
              player.weapon = stolen;
              send(player.ws, { type: "notice", text: `Você pegou a ${stolen} do inimigo!` });
            }
          }
          send(player.ws, {
            type: "notice",
            text: `Eliminação de ${target.name}! ${room.mode === "ranked" ? `+${reward} pts.` : ""}`
          });
          send(target.ws, { type: "notice", text: `Você foi derrubado por ${player.name}.` });
          checkArenaRound(room);
        }
        broadcastRoom(room);
      }

      else if (msg.action === "pickupHunter") {
        if (room.mode === "arena4v4") return;
        if (!rateLimit(player, "pickup", 500)) return;
        const item = room.hunterItems.find(i => !i.taken && Math.hypot(i.x - player.x, i.y - player.y) < 65);
        if (!item) return send(ws, { type: "notice", text: "Nenhum Olho do Caçador próximo." });

        // Limite: no máximo 2 por jogador (normalmente 1 + roubo)
        if (player.hunterDevices >= 2) {
          return send(ws, { type: "notice", text: "Você já carrega o máximo de Olhos do Caçador." });
        }
        item.taken = true;
        player.hunterDevices++;
        send(ws, { type: "notice", text: "Olho do Caçador coletado! Uso único — revela inimigos." });
        broadcastRoom(room);
      }

      else if (msg.action === "hunter") {
        if (player.hunterDevices <= 0) return send(ws, { type: "notice", text: "Você não tem Olho do Caçador." });
        if (!rateLimit(player, "hunter", 1000)) return;
        player.hunterDevices--;
        const enemies = [...players.values()]
          .filter(t => t.room === player.room && t.teamId !== player.teamId && !t.eliminated)
          .map(t => ({ name: t.name, x: t.x, y: t.y, teamId: t.teamId }));
        send(ws, { type: "tracking", enemies });
        send(ws, { type: "notice", text: "Olho do Caçador ativado e consumido! 10 segundos de visão." });
        broadcastRoom(room);
      }

      else if (msg.action === "skill") {
        if (!rateLimit(player, "skill", 6000)) return send(ws, { type: "notice", text: "Habilidade recarregando." });
        if (player.ep < 40) return send(ws, { type: "notice", text: "EP insuficiente (custa 40)." });
        player.ep -= 40;
        const now = Date.now();
        const teammates = [...players.values()].filter(t =>
          t.room === player.room && t.teamId === player.teamId && !t.eliminated &&
          Math.hypot(t.x - player.x, t.y - player.y) < 190
        );
        const enemies = [...players.values()].filter(t =>
          t.room === player.room && t.teamId !== player.teamId && !t.eliminated &&
          Math.hypot(t.x - player.x, t.y - player.y) < 190 &&
          !(t.spawnProtectUntil > now)
        );

        if (player.playerClass === "Curandeiro" || player.playerClass === "Druida") {
          for (const t of (player.playerClass === "Druida" ? [player] : teammates)) {
            t.hp = Math.min(200, t.hp + (player.playerClass === "Druida" ? 55 : 35));
          }
          send(ws, {
            type: "notice",
            text: player.playerClass === "Druida"
              ? "Raízes vitais: +55 de vida."
              : "Cura em área nos aliados próximos."
          });
        } else if (player.playerClass === "Guerreiro") {
          player.hp = Math.min(200, player.hp + 20);
          player.skillBoostUntil = now + 3500;
          send(ws, { type: "notice", text: "Ímpeto do Guerreiro: +20 vida e força temporária." });
        } else {
          const damage = player.playerClass === "Mago" ? 42 : player.playerClass === "Assassino" ? 36 : 30;
          for (const t of enemies) {
            let d = damage;
            if (t.crouching && t.playerClass === "Guerreiro") d = Math.ceil(d * 0.6);
            t.hp = Math.max(0, t.hp - d);
            if (t.hp === 0) {
              player._killInc = (player._killInc || 0) + 1;
              if (room.mode === "arena4v4") t.eliminated = true;
              else {
                t.hp = 200;
                t.spawnProtectUntil = Date.now() + 3500;
                const sp = room.teamSpawns.get(t.teamId);
                if (sp) { t.x = sp.x; t.y = sp.y; }
              }
              if (room.mode === "ranked") {
                player.rankedPoints += rankedKillReward(player.rankedPoints, player.isDev);
                t.rankedPoints = Math.max(0, t.rankedPoints - 5);
                persistProgress(player);
                persistProgress(t);
              }
              if (t.hunterDevices > 0) {
                player.hunterDevices += t.hunterDevices;
                t.hunterDevices = 0;
              }
            }
          }
          send(ws, {
            type: "notice",
            text: player.playerClass === "Mago" ? "Explosão arcana!" :
              player.playerClass === "Arqueiro" ? "Rajada precisa!" : "Ataque especial!"
          });
          checkArenaRound(room);
        }
        broadcastRoom(room);
      }

      else if (msg.action === "gather") {
        if (!rateLimit(player, "gather", 600)) return;
        const roll = Math.random();
        if (roll < 0.55) {
          player.wood += 1;
          room.wood += 1;
          send(ws, { type: "notice", text: "Você coletou 1 madeira." });
        } else {
          player.berries += 1;
          room.berries += 1;
          send(ws, { type: "notice", text: "Você encontrou 1 fruta." });
        }
        if (Math.random() < 0.07 && player.weapon === "mão") {
          const drops = ["faca", "espada", "arco", "machado"];
          player.weapon = drops[Math.floor(Math.random() * drops.length)];
          send(ws, { type: "notice", text: `Você encontrou uma ${player.weapon}!` });
        }
        broadcastRoom(room);
      }

      else if (msg.action === "eat") {
        if (player.berries > 0 && player.hunger < 100) {
          player.berries--;
          player.hunger = Math.min(100, player.hunger + 35);
          send(ws, { type: "notice", text: "Você comeu uma fruta." });
          broadcastRoom(room);
        } else {
          send(ws, { type: "notice", text: player.berries ? "Fome já está cheia." : "Sem frutas." });
        }
      }

      else if (msg.action === "campfire") {
        if (player.wood >= 5) {
          player.wood -= 5;
          room.wood = Math.max(0, room.wood - 5);
          room.night = false;
          room.day += 1;
          room.lastDayChange = Date.now();
          for (const p of players.values()) {
            if (p.room === player.room) p.hp = Math.min(200, p.hp + 15);
          }
          send(ws, { type: "notice", text: "Fogueira acesa! Todos recuperaram vida." });
          broadcastRoom(room);
        } else {
          send(ws, { type: "notice", text: "Precisa de 5 madeiras." });
        }
      }

      else if (msg.action === "build") {
        if (player.wood < 8) {
          return send(ws, { type: "notice", text: "Precisa de 8 madeiras para construir." });
        }
        if ((room.buildings || []).length >= 45) {
          return send(ws, { type: "notice", text: "Limite de construções da sala." });
        }
        const tooClose = (room.buildings || []).some(b => Math.hypot(b.x - player.x, b.y - player.y) < 50);
        if (tooClose) return send(ws, { type: "notice", text: "Muito perto de outra construção." });

        player.wood -= 8;
        const buildType = msg.buildType === "muro" ? "muro" : "abrigo";
        room.buildings.push({
          id: Math.random().toString(36).slice(2, 8),
          x: player.x,
          y: player.y - 8,
          ownerId: player.id,
          teamId: player.teamId,
          hp: buildType === "muro" ? 120 : 80,
          type: buildType
        });
        send(ws, { type: "notice", text: buildType === "muro" ? "Muro construído!" : "Abrigo construído!" });
        broadcastRoom(room);
      }
    }
  });

  ws.on("close", () => {
    persistProgress(player);
    const oldRoom = rooms.get(player.room);
    players.delete(id);
    if (oldRoom) {
      checkArenaRound(oldRoom);
      broadcastRoom(oldRoom);
    }
  });
  ws.on("error", () => {});
});

function broadcastRoom(room) {
  const state = JSON.stringify(publicState(room));
  for (const p of players.values()) {
    if (p.room === room.key && p.ws.readyState === WebSocket.OPEN) p.ws.send(state);
  }
}

// Loop principal
setInterval(() => {
  const now = Date.now();

  for (const p of players.values()) {
    if (p.eliminated) continue;
    const speed = p.crouching ? 2.4 : 4.3;
    let dx = (p.input.right ? 1 : 0) - (p.input.left ? 1 : 0);
    let dy = (p.input.down ? 1 : 0) - (p.input.up ? 1 : 0);
    if (dx && dy) { dx *= 0.7071; dy *= 0.7071; }
    const activeRoom = rooms.get(p.room);
    const map = activeRoom && activeRoom.mode === "arena4v4" ? { width: 1200, height: 900 } : WORLD;
    p.x = clamp(p.x + dx * speed, 22, map.width - 22);
    p.y = clamp(p.y + dy * speed, 22, map.height - 22);

    if (now - (p.lastEpTick || now) > 1000) {
      p.lastEpTick = now;
      p.ep = Math.min(200, p.ep + 2);
    }
    if (now - (p.lastHungerTick || now) > 12000 && p.mode !== "arena4v4") {
      p.lastHungerTick = now;
      p.hunger = Math.max(0, p.hunger - 1);
      if (p.hunger === 0) p.hp = Math.max(0, p.hp - 2);
      if (p.hp <= 0) {
        p.hp = 200;
        p.hunger = 55;
        p.spawnProtectUntil = now + 3000;
        const room = rooms.get(p.room);
        const spawn = room && room.teamSpawns.get(p.teamId);
        p.x = spawn ? spawn.x : 1600;
        p.y = spawn ? spawn.y : 1100;
      }
    }
  }

  for (const room of rooms.values()) {
    if (room.mode === "arena4v4") {
      broadcastRoom(room);
      continue;
    }

    // Spawn de monstros
    if (now - (room.lastMonsterSpawn || 0) > 13000) {
      room.lastMonsterSpawn = now;
      spawnMonster(room);
      if (Math.random() < 0.5) spawnMonster(room);
    }

    // IA dos monstros
    for (const m of room.monsters) {
      let nearest = null;
      let nearestD = 440;
      for (const p of players.values()) {
        if (p.room !== room.key || p.eliminated) continue;
        if (p.spawnProtectUntil > now) continue;
        const d = Math.hypot(p.x - m.x, p.y - m.y);
        if (d < nearestD) {
          nearestD = d;
          nearest = p;
        }
      }
      if (nearest) {
        const dx = nearest.x - m.x;
        const dy = nearest.y - m.y;
        const dist = Math.hypot(dx, dy) || 1;
        const speed = m.type === "besta" ? 2.2 : m.type === "esqueleto" ? 2.0 : 1.5;
        m.x += (dx / dist) * speed;
        m.y += (dy / dist) * speed;

        if (dist < 36 && now - (m.lastAttack || 0) > 1500) {
          m.lastAttack = now;
          let dmg = m.type === "besta" ? 15 : m.type === "esqueleto" ? 11 : 9;
          if (nearest.crouching && nearest.playerClass === "Guerreiro") dmg = Math.ceil(dmg * 0.55);
          const nearBuilding = (room.buildings || []).some(b =>
            b.teamId === nearest.teamId && Math.hypot(b.x - nearest.x, b.y - nearest.y) < 70
          );
          if (nearBuilding) dmg = Math.ceil(dmg * 0.55);
          nearest.hp = Math.max(0, nearest.hp - dmg);
          if (nearest.hp <= 0) {
            nearest.hp = 200;
            nearest.hunger = 50;
            nearest.spawnProtectUntil = now + 3000;
            const sp = room.teamSpawns.get(nearest.teamId);
            if (sp) { nearest.x = sp.x; nearest.y = sp.y; }
            send(nearest.ws, { type: "notice", text: `Você foi derrubado por um ${m.type}!` });
          }
        }
      }
    }

    // Ciclo dia/noite
    if (now - room.lastDayChange > 90000) {
      room.night = !room.night;
      room.lastDayChange = now;
      if (!room.night) room.day += 1;
    }

    broadcastRoom(room);
  }
}, TICK_MS);

// Salva progresso periodicamente
setInterval(() => {
  for (const p of players.values()) {
    if (p.name && p.name !== "Sobrevivente") persistProgress(p);
  }
}, 30000);

server.listen(PORT, "0.0.0.0", () => {
  console.log(`Ilha Coop rodando na porta ${PORT}`);
  console.log(`Dados salvos em: ${PLAYERS_FILE}`);
});
