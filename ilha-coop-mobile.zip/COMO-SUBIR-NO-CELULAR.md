# Como colocar o Ilha Coop online só pelo celular

Você **não precisa de computador**. Tudo pelo navegador do celular.

## Passo a passo (Render — grátis)

1. No celular, abra o Chrome ou Safari e entre em:  
   **https://render.com**

2. Crie conta grátis (pode usar Google/GitHub).

3. Toque em **New +** → **Web Service**.

4. Escolha **public Git repository** **ou** faça upload do ZIP:
   - Se tiver o ZIP salvo no celular, use a opção de conectar repositório
     ou envie o projeto pelo GitHub (app GitHub no celular também serve).

5. Configurações:
   - **Name:** ilha-coop (ou qualquer nome)
   - **Runtime:** Node
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Instance type:** Free

6. Toque em **Create Web Service**.

7. Espere 2–5 minutos. Quando ficar **Live**, copie o link  
   (exemplo: `https://ilha-coop-xxxx.onrender.com`).

8. Abra esse link **no celular** e jogue.  
   Envie o mesmo link para os amigos entrarem.

## Dicas importantes

- No plano grátis o site “dorme” após um tempo sem uso.  
  Na primeira abertura do dia pode demorar ~30–60s para acordar.
- Use o **mesmo código de sala** (ex: ILHA) para jogar junto.
- Nick **não pode repetir** enquanto a pessoa estiver online.
- Nome com **Atlas_dev** ativa conta de desenvolvedor (selo ✓ + bônus).

## Controles no celular

- Direcional na esquerda  
- Botões de ação na direita  
- Agachar, atacar, construir, Olho do Caçador, chat
