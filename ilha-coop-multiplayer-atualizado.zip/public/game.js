(() => {
  const canvas = document.getElementById("game"), ctx = canvas.getContext("2d");
  const $ = id => document.getElementById(id);
  let ws, myId = null, room = "ILHA", mode = "classic", world = {width:3200,height:2200}, state = null;
  let camera = {x:0,y:0}, held = {up:false,down:false,left:false,right:false}, noticeTimer, tracking=[], trackingTimer, crouching=false;
  const trees = [], bushes = [], rocks = [];
  // Deterministic-looking decorative resources, rendered locally.
  for (let i=0;i<125;i++) {
    const x = 80 + ((i*197 + (i%7)*83) % 2240), y = 80 + ((i*131 + (i%11)*47) % 1440);
    if (i%3===0) rocks.push({x,y,r:8+(i%5)});
    else if (i%4===0) bushes.push({x,y,r:10+(i%5)});
    else trees.push({x,y,r:14+(i%10)});
  }
  function resize(){const dpr=Math.min(devicePixelRatio||1,2);canvas.width=Math.floor(canvas.clientWidth*dpr);canvas.height=Math.floor(canvas.clientHeight*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);}
  window.addEventListener("resize",resize); resize();
  function send(obj){if(ws && ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify(obj));}
  function showNotice(text){$("notice").textContent=text;$("notice").classList.add("show");clearTimeout(noticeTimer);noticeTimer=setTimeout(()=>$("notice").classList.remove("show"),2200);}
  function connect(){
    const proto=location.protocol==="https:"?"wss:":"ws:";
    ws=new WebSocket(`${proto}//${location.host}`);
    $("connection").textContent="Conectando…";
    ws.onopen=()=>{$("connection").textContent="● Online";send({type:"join",name:$("nameInput").value,room:$("roomInput").value,mode:$("modeInput").value,race:$("raceInput").value,playerClass:$("classInput").value});};
    ws.onclose=()=>{$("connection").textContent="Desconectado";setTimeout(()=>{if(!$("joinScreen").classList.contains("hidden"))return;connect();},2000);};
    ws.onerror=()=>{$("connection").textContent="Erro de conexão";};
    ws.onmessage=e=>{let m;try{m=JSON.parse(e.data)}catch{return}
      if(m.type==="welcome"){myId=m.id;world=m.world||world;}
      if(m.type==="joined"){room=m.room;mode=m.mode||mode;$("roomBadge").textContent="Sala: "+room+" · "+(m.modeLabel||mode);$("joinScreen").classList.add("hidden");showNotice("Entrou em "+(m.modeLabel||mode)+" · Cidade: "+(m.city||"—"));}
      if(m.type==="error"){$("joinError").textContent=m.message;showNotice(m.message);}
      if(m.type==="state"){state=m;world=m.world||world;updateHud();}
      if(m.type==="notice")showNotice(m.text);
      if(m.type==="chat"){const row=document.createElement("div");row.className="chatLine";row.textContent=`${m.channel==="team"?"[Equipe]":"[Global]"} ${m.from}: ${m.text}`;$("chatMessages").appendChild(row);while($("chatMessages").children.length>25)$("chatMessages").firstChild.remove();$("chatMessages").scrollTop=$("chatMessages").scrollHeight;}
      if(m.type==="tracking"){tracking=m.enemies||[];clearTimeout(trackingTimer);trackingTimer=setTimeout(()=>tracking=[],10000);showNotice("Inimigos revelados por 10 segundos!");}
    };
  }
  $("joinBtn").addEventListener("click",()=>{if(ws && ws.readyState===WebSocket.OPEN){$("joinError").textContent="";send({type:"join",name:$("nameInput").value,room:$("roomInput").value,mode:$("modeInput").value,race:$("raceInput").value,playerClass:$("classInput").value});}else connect();});
  function updateHud(){
    if(!state)return;const me=state.players.find(p=>p.id===myId);if(!me)return;
    $("hp").textContent=me.hp+"/200";$("ep").textContent=me.ep??200;$("hpBar").style.width=(me.hp/2)+"%";$("hunger").textContent=me.hunger;$("hungerBar").style.width=me.hunger+"%";
    $("wood").textContent=me.wood;$("berries").textContent=me.berries;$("day").textContent=state.resources.day;
    $("playersCount").textContent=state.players.length+"/"+(state.mode==="arena4v4"?8:20)+" jogadores";
    $("modeHud").textContent=state.modeLabel||state.mode||"CLÁSSICO";
    $("cityHud").textContent="Cidade: "+(me.city||"—");
    $("rankHud").textContent=state.mode==="arena4v4"?"4x4: "+(me.arenaRank||"Bronze I")+" · "+(me.arenaStars||0)+"★":(state.mode==="ranked"?(me.rankedRank||"Bronze I")+" · "+(me.rankedPoints||0)+" pts":"Sem pontos de ranque" );
    $("pickupBtn").style.opacity=me.hasHunterDevice?".65":"1";
  }
  function inputSend(){send({type:"input",...held,crouching});}
  document.querySelectorAll("[data-dir]").forEach(btn=>{
    const dir=btn.dataset.dir;
    const down=e=>{e.preventDefault();held[dir]=true;btn.classList.add("active");inputSend();};
    const up=e=>{e.preventDefault();held[dir]=false;btn.classList.remove("active");inputSend();};
    btn.addEventListener("pointerdown",down);btn.addEventListener("pointerup",up);btn.addEventListener("pointercancel",up);btn.addEventListener("pointerleave",e=>{if(e.buttons)up(e);});
  });
  window.addEventListener("keydown",e=>{const map={ArrowUp:"up",w:"up",ArrowDown:"down",s:"down",ArrowLeft:"left",a:"left",ArrowRight:"right",d:"right"};const k=map[e.key];if(k){held[k]=true;inputSend();}});
  window.addEventListener("keyup",e=>{const map={ArrowUp:"up",w:"up",ArrowDown:"down",s:"down",ArrowLeft:"left",a:"left",ArrowRight:"right",d:"right"};const k=map[e.key];if(k){held[k]=false;inputSend();}});
  $("gatherBtn").onclick=()=>send({type:"action",action:"gather"});
  $("eatBtn").onclick=()=>send({type:"action",action:"eat"});
  $("campBtn").onclick=()=>send({type:"action",action:"campfire"});
  $("attackBtn").onclick=()=>send({type:"action",action:"attack"});
  $("skillBtn").onclick=()=>send({type:"action",action:"skill"});
  $("crouchBtn").onclick=()=>{crouching=!crouching;$("crouchBtn").classList.toggle("active",crouching);inputSend();showNotice(crouching?"Defesa: agachado":"Você se levantou");};
  $("pickupBtn").onclick=()=>send({type:"action",action:"pickupHunter"});
  $("hunterBtn").onclick=()=>send({type:"action",action:"hunter"});
  function sendChat(){const text=$("chatInput").value.trim();if(!text)return;send({type:"chat",channel:$("chatChannel").value,text});$("chatInput").value="";}
  $("chatSend").onclick=sendChat;$("chatInput").addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();sendChat();}});
  function circle(x,y,r,fill,stroke){ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=2;ctx.stroke();}}
  function drawCity(city){
    const capital=city.type==="capital";const r=city.radius||180;
    ctx.fillStyle=capital?"#b79b5b22":"#d6d7b515";ctx.beginPath();ctx.arc(city.x,city.y,r,0,Math.PI*2);ctx.fill();
    ctx.strokeStyle=capital?"#e5c87a99":"#c8d5a655";ctx.lineWidth=capital?5:3;ctx.beginPath();ctx.arc(city.x,city.y,r,0,Math.PI*2);ctx.stroke();
    // Small block-like buildings make the named city zones visible on the prototype map.
    const blocks=capital?14:7;
    for(let i=0;i<blocks;i++){const a=i*2.39996;const dist=capital?75+(i%4)*45:45+(i%3)*35;const x=city.x+Math.cos(a)*dist,y=city.y+Math.sin(a)*dist;ctx.fillStyle=capital?"#d5c69b":"#9aaf9b";ctx.fillRect(x-10,y-8,20,16);ctx.fillStyle="#6e8d79";ctx.fillRect(x-7,y-5,14,10);}
    ctx.fillStyle=capital?"#ffe4a0":"#f1f5dc";ctx.font=capital?"bold 22px system-ui":"bold 15px system-ui";ctx.textAlign="center";ctx.fillText(city.name,city.x,city.y-r-14);
    if(capital){ctx.font="10px system-ui";ctx.fillText("CAPITAL PRINCIPAL",city.x,city.y-r+3);}
  }
  function draw(){
    requestAnimationFrame(draw);
    const w=canvas.clientWidth,h=canvas.clientHeight;
    ctx.clearRect(0,0,w,h);
    ctx.fillStyle="#25483b";ctx.fillRect(0,0,w,h);
    if(!state){ctx.fillStyle="#d4e8dc";ctx.font="14px system-ui";ctx.fillText("Conectando à ilha…",20,40);return;}
    const me=state.players.find(p=>p.id===myId);
    if(me){camera.x=Math.max(0,Math.min(world.width-w,me.x-w/2));camera.y=Math.max(0,Math.min(world.height-h,me.y-h/2));}
    ctx.save();ctx.translate(-camera.x,-camera.y);
    // Ground patches
    for(let i=0;i<90;i++){const x=(i*281)%world.width,y=(i*173)%world.height;ctx.fillStyle=i%2?"#2a503f":"#2b4d3e";ctx.beginPath();ctx.ellipse(x,y,35+(i%5)*8,17+(i%4)*6,i%3,0,Math.PI*2);ctx.fill();}
    // Beach border
    ctx.strokeStyle="#8bbd91";ctx.lineWidth=18;ctx.strokeRect(10,10,world.width-20,world.height-20);
    // Hunter devices are visible collectible objectives on the ranked/classic map.
    (state.hunterItems||[]).forEach(item=>{circle(item.x,item.y,13,"#172b32","#f3d46b");circle(item.x,item.y,6,"#f5d66e");ctx.fillStyle="#fff2b8";ctx.font="10px system-ui";ctx.textAlign="center";ctx.fillText("OLHO",item.x,item.y-18);});
    // Cities of the Greek-inspired world; Atlas is the largest capital.
    if(state.cities && state.cities.length){state.cities.forEach(drawCity);}
    else {drawCity({name:"ARENA 4x4",x:600,y:450,radius:280,type:"capital"});}
    trees.forEach(t=>{circle(t.x,t.y+5,t.r*.75,"#173a2c");circle(t.x,t.y,t.r,"#34724a","#245539");circle(t.x-t.r*.25,t.y-t.r*.25,t.r*.32,"#4d8d5a");});
    bushes.forEach(b=>{circle(b.x,b.y,b.r,"#648b48","#41653b");circle(b.x-3,b.y-3,3,"#d76d78");circle(b.x+4,b.y+2,3,"#d76d78");});
    rocks.forEach(r=>{circle(r.x,r.y,r.r,"#78867d","#56645d");circle(r.x-3,r.y-3,r.r*.35,"#9aa79c");});
    // Community camp
    const fireX=state.mode==="arena4v4"?600:1600, fireY=state.mode==="arena4v4"?450:1100;circle(fireX,fireY,45,"#18372e","#d6b97a");circle(fireX,fireY,28,"#6a4d32");circle(fireX,fireY,16,"#f6a34b");circle(fireX-5,fireY-5,7,"#ffe08a");
    ctx.fillStyle="#f7e3aa";ctx.font="12px system-ui";ctx.textAlign="center";ctx.fillText(state.mode==="arena4v4"?"CENTRO DA ARENA":"FOGUEIRA CENTRAL",fireX,fireY-60);
    for(const enemy of tracking){circle(enemy.x,enemy.y,25,"#ff353522","#ff6969");ctx.fillStyle="#ffaaaa";ctx.font="bold 11px system-ui";ctx.textAlign="center";ctx.fillText("INIMIGO",enemy.x,enemy.y-30);}
    for(const p of state.players){
      if(p.eliminated){ctx.fillStyle="#c6d0cc";ctx.font="10px system-ui";ctx.textAlign="center";ctx.fillText("ELIMINADO",p.x,p.y-18);continue;}
      circle(p.x,p.y+8,12,"#142a22aa");
      circle(p.x,p.y,p.crouching?10:12,p.color,"#e5f6e9");
      if(p.isVerified){ctx.fillStyle="#72c9ff";ctx.font="bold 12px system-ui";ctx.fillText("✓",p.x+12,p.y-10);}
      circle(p.x-3,p.y-3,3,"#fff");
      ctx.fillStyle="#f4f8f4";ctx.font="12px system-ui";ctx.textAlign="center";ctx.fillText(p.name+(p.id===myId?" (você)":""),p.x,p.y-20);
      ctx.fillStyle="#27332c";ctx.fillRect(p.x-13,p.y+16,26,4);ctx.fillStyle="#79e2a0";ctx.fillRect(p.x-13,p.y+16,26*p.hp/200,4);
    }
    ctx.restore();
    // Soft dark edge overlay
    const grad=ctx.createRadialGradient(w/2,h/2,Math.min(w,h)*.25,w/2,h/2,Math.max(w,h)*.7);grad.addColorStop(0,"#00000000");grad.addColorStop(1,"#08141035");ctx.fillStyle=grad;ctx.fillRect(0,0,w,h);
  }
  connect();draw();
})();