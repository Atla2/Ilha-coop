# Ilha Coop — protótipo multiplayer atualizado

Protótipo 2D de sobrevivência cooperativa para navegador mobile, usando Node.js e WebSocket (`ws`). Esta versão inclui uma primeira implementação dos sistemas abaixo; ainda não é um jogo comercial pronto nem foi validada em uma partida online completa.

## Recursos incluídos nesta versão

- Modos de sala: **Ranqueado**, **Clássico** e **4x4**.
- Até 20 jogadores nos modos Ranqueado/Clássico e até 8 no 4x4.
- Equipes de até quatro jogadores e escolha de spawn que considera ocupação das cidades e distância entre equipes.
- Mapa principal 3200×2200 com as cidades Atlas (capital), Poseidon, Atena, Ares, Ártemis e Hefesto.
- Arena compacta para o 4x4, com spawns em lados opostos.
- Vida 200, EP 200 com regeneração, fome, madeira, frutas e fogueira.
- Raças e classes selecionáveis: Humano, Elfo, Fada, Duende, Anão, Elfo Negro; Guerreiro, Mago, Curandeiro, Arqueiro, Assassino e Druida.
- Ataque básico e habilidades de classe que consomem 40 EP e têm recarga.
- Sem dano direto a integrantes da própria equipe. Guerreiro reduz dano recebido enquanto está agachado.
- Chat de equipe e global com limite de tamanho e intervalo anti-spam básico.
- Olho do Caçador: itens coletáveis no mapa, revelação temporária dos inimigos e transferência do item quando seu portador é eliminado por outro jogador.
- Ranqueado: pontos por eliminações, penalidade pequena ao ser eliminado e patentes exibidas a partir dos pontos.
- 4x4: as equipes vencem a rodada quando eliminam todos os adversários; cada vitória concede uma estrela e a cada três estrelas a patente avança. A progressão usa uma trilha separada.

## Ainda não implementado ou incompleto

- Contas persistentes e banco de dados; por enquanto, pontos, estrelas e escolhas são mantidos em memória e se perdem quando o servidor reinicia.
- Identificação segura do desenvolvedor por ID de conta, selo verificado exclusivo e bônus de pontos pessoal.
- Persistência de ranques entre partidas, matchmaking por habilidade, temporadas e balanceamento completo.
- Sistema completo de construções, casas, armas variadas, animais, animações, música e efeitos sonoros.
- Voz por WebRTC e serviço TURN.
- Editor de posição/tamanho/transparência dos controles com salvamento.
- Limites de frequência e validações anti-trapaça mais fortes; o protótipo ainda precisa de auditoria de segurança e testes de carga.
- O Olho do Caçador tem pontos fixos coletáveis compartilhados pela sala; a regra final de exatamente um item inicial por equipe ainda precisa ser refinada.

## Executar localmente

Requer Node.js 18 ou superior e conexão para instalar a dependência `ws`.

```bash
npm install
npm start
```

Depois abra `http://localhost:3000` no navegador. Para jogar pela internet, hospede o servidor em uma plataforma que aceite processos Node.js e WebSocket; um arquivo ZIP sozinho não hospeda o jogo.

## Avisos

- A sintaxe dos arquivos JavaScript foi verificada com `node --check`.
- A dependência `ws` não estava instalada no ambiente de edição, então não foi possível executar um teste de ponta a ponta nem validar a conexão entre vários dispositivos.
- O sistema atual é uma base experimental e não deve ser anunciado como versão online pronta.
