const http = require("http");
const fs = require("fs");
const path = require("path");
const { WebSocketServer, WebSocket } = require("ws");

const PORT = process.env.PORT || 3000;
const PUBLIC = path.join(__dirname, "public");
const MAX_PLAYERS = 20;
const WORLD = { width: 3200, height: 2200 };
const CITIES = [
  { name: "Atlas", x: 1600, y: 1100, radius: 390, type: "capital" },
  { name: "Poseidon", x: 520, y: 500, radius: 250, type: "coastal" },
  { name: "Atena", x: 2650, y: 480, radius: 250, type: "knowledge" },
  { name: "Ares", x: 500, y: 1740, radius: 250, type: "fortress" },
  { name: "Ártemis", x: 2700, y: 1720, radius: 250, type: "forest" },
  { name: "Hefesto", x: 1600, y: 300, radius: 220, type: "forge" }
];
const MODES = { ranked: { label: "Ranqueado", maxPlayers: 20, teamSize: 4 }, classic: { label: "Clássico", maxPlayers: 20, teamSize: 4 }, arena4v4: { label: "4x4", maxPlayers: 8, teamSize: 4, smallMap: true } };
const TICK_MS = 50;
const RACES = ["Humano", "Elfo", "Fada", "Duende", "Anão", "Elfo Negro"];
const CLASSES = ["Guerreiro", "Mago", "Curandeiro", "Arqueiro", "Assassino", "Druida"];
const ARENA_RANKS = ["Bronze I","Bronze II","Bronze III","Prata I","Prata II","Prata III","Prata IV","Ouro I","Ouro II","Ouro III","Ouro IV", ...Array.from({length:10},(_,i)=>`Safira ${["I","II","III","IV","V","VI","VII","VIII","IX","X"][i]}`),"Rei"];
const RACE_WEAKNESS = {"Humano":"Elfo","Elfo":"Duende","Duende":"Fada","Fada":"Elfo Negro","Elfo Negro":"Anão","Anão":"Humano"};
const players = new Map();
const rooms = new Map();

function roomFor(code, mode = "classic") {
  const roomCode = (code || "ILHA").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8) || "ILHA";
  const safeMode = MODES[mode] ? mode : "classic";
  const key = `${safeMode}:${roomCode}`;
  if (!rooms.has(key)) rooms.set(key, { key, code: roomCode, mode: safeMode, wood: 0, berries: 0, day: 1, night: false, lastDayChange: Date.now(), teamSpawns: new Map(), spawnCounts: new Map(), nextTeamId: 0, hunterItems: [{x:360,y:360,taken:false},{x:2800,y:360,taken:false},{x:420,y:1840,taken:false},{x:2780,y:1840,taken:false},{x:1600,y:300,taken:false},{x:1600,y:1850,taken:false}], round: 1, roundEnding: false });
  return rooms.get(key);
}
function pickSpawn(room, teamId) {
  const mode = MODES[room.mode];
  if (mode.smallMap) {
    const arena = [{x:260,y:450},{x:940,y:450}];
    const side = teamId % 2;
    const offset = Math.floor(teamId / 2) * 30;
    const chosen = {city:"Arena 4x4",x:arena[side].x+(side ? -offset : offset),y:arena[side].y+offset};
    room.teamSpawns.set(teamId, chosen); return chosen;
  }
  // Score each city by occupancy and distance from all existing team spawns.
  const candidates = CITIES.map((city, index) => {
    const count = room.spawnCounts.get(city.name) || 0;
    const angle = ((teamId * 2.3999632297 + index * 1.7) % (Math.PI * 2));
    const spread = Math.min(city.radius * 0.62, 95 + count * 28);
    const x = city.x + Math.cos(angle) * spread, y = city.y + Math.sin(angle) * spread;
    let nearest = Infinity;
    for (const pos of room.teamSpawns.values()) nearest = Math.min(nearest, Math.hypot(x-pos.x,y-pos.y));
    const distanceScore = Number.isFinite(nearest) ? Math.min(nearest, 1800) : 1800;
    const score = distanceScore - count * 950 + (city.type === "capital" ? -180 : 0) + Math.random()*90;
    return {city,x,y,score};
  });
  candidates.sort((a,b)=>b.score-a.score);
  const chosen = candidates[0];
  room.spawnCounts.set(chosen.city.name,(room.spawnCounts.get(chosen.city.name)||0)+1);
  room.teamSpawns.set(teamId,{x:chosen.x,y:chosen.y,city:chosen.city.name});
  return {city:chosen.city.name,x:chosen.x,y:chosen.y};
}
function rankedRank(points) {
  const roman=["I","II","III","IV","V","VI","VII","VIII","IX","X"];
  if(points>=5000)return "Rei";
  if(points>=900)return `Safira ${roman[Math.min(9,Math.floor((points-900)/410))]}`;
  if(points>=400)return `Ouro ${roman[Math.min(3,Math.floor((points-400)/125))]}`;
  if(points>=100)return `Prata ${roman[Math.min(3,Math.floor((points-100)/75))]}`;
  return `Bronze ${roman[Math.min(2,Math.floor(points/34))]}`;
}
function rankedKillReward(points){return points<100?30:points<400?25:points<900?20:points<2500?15:10;}
function rankForStars(stars) {
  let remaining = Math.max(0, stars);
  let index = 0;
  while (index < ARENA_RANKS.length-1 && remaining >= 3) { remaining -= 3; index++; }
  return {rank:ARENA_RANKS[index], stars:remaining, rankIndex:index};
}
function teamAlive(room, teamId) {
  return [...players.values()].some(p=>p.room===room.key && p.teamId===teamId && !p.eliminated);
}
function checkArenaRound(room) {
  if (room.mode !== "arena4v4" || room.roundEnding) return;
  const teams = [...new Set([...players.values()].filter(p=>p.room===room.key).map(p=>p.teamId))];
  if (teams.length < 2) return;
  const alive = teams.filter(t=>teamAlive(room,t));
  if (alive.length !== 1) return;
  room.roundEnding = true;
  const winner = alive[0];
  for (const p of players.values()) if (p.room===room.key) {
    if (p.teamId===winner) { p.arenaStarsTotal += 1; const r=rankForStars(p.arenaStarsTotal); p.arenaRank=r.rank; p.arenaStars=r.stars; send(p.ws,{type:"notice",text:`Vitória no 4x4! Você ganhou 1 estrela. Patente: ${p.arenaRank} (${p.arenaStars}★)`}); }
    else send(p.ws,{type:"notice",text:"Sua equipe perdeu a rodada. Tente novamente!"});
  }
  setTimeout(()=>{
    for (const p of players.values()) if(p.room===room.key){p.hp=200;p.eliminated=false;const sp=room.teamSpawns.get(p.teamId);if(sp){p.x=sp.x+(Math.random()-.5)*60;p.y=sp.y+(Math.random()-.5)*60;p.city=sp.city;}}
    room.round++;room.roundEnding=false;broadcastRoom(room);
  },3500);
}

function send(ws, data) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data));
}
function safeName(value) {
  return String(value || "Sobrevivente").replace(/[<>]/g, "").trim().slice(0, 18) || "Sobrevivente";
}
function clamp(n, lo, hi) { return Math.max(lo, Math.min(hi, n)); }
function publicState(room) {
  return {
    type: "state", room: room.code, mode: room.mode, modeLabel: MODES[room.mode].label, world: room.mode === "arena4v4" ? {width: 1200, height: 900, smallMap: true} : WORLD,
    cities: room.mode === "arena4v4" ? [] : CITIES,
    resources: { wood: room.wood, berries: room.berries, day: room.day, night: room.night },
    hunterItems: room.mode === "arena4v4" ? [] : room.hunterItems.filter(i=>!i.taken), round: room.round,
    players: [...players.values()].filter(p => p.room === room.key).map(p => ({
      id: p.id, name: p.name, x: p.x, y: p.y, hp: p.hp, hunger: p.hunger,
      wood: p.wood, berries: p.berries, color: p.color, teamId: p.teamId, city: p.city,
      rankedPoints: p.rankedPoints, rankedRank: rankedRank(p.rankedPoints), arenaStars: p.arenaStars, arenaRank: p.arenaRank, ep: p.ep, race: p.race, playerClass: p.playerClass, crouching: p.crouching, eliminated: p.eliminated, hasHunterDevice: p.hunterDevices > 0, isVerified: p.isVerified
    }))
  };
}

const server = http.createServer((req, res) => {
  let pathname = decodeURIComponent((req.url || "/").split("?")[0]);
  if (pathname === "/") pathname = "/index.html";
  const file = path.normalize(path.join(PUBLIC, pathname));
  if (!file.startsWith(PUBLIC)) { res.writeHead(403); return res.end("Forbidden"); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end("Not found"); }
    const ext = path.extname(file);
    const types = { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "application/javascript; charset=utf-8", ".json": "application/json; charset=utf-8" };
    res.writeHead(200, { "Content-Type": types[ext] || "application/octet-stream", "Cache-Control": "no-store" });
    res.end(data);
  });
});

const wss = new WebSocketServer({ server });
wss.on("connection", (ws) => {
  const id = Math.random().toString(36).slice(2, 10);
  const player = {
    id, ws, room: null, mode: "classic", teamId: 0, city: "Atlas", name: "Sobrevivente", x: 1600, y: 1100,
    hp: 200, ep: 200, hunger: 100, wood: 0, berries: 0, rankedPoints: 0, arenaStars: 0, arenaStarsTotal: 0, arenaRank: "Bronze I", race: "Humano", playerClass: "Guerreiro", crouching: false, eliminated: false, hunterDevices: 0, isVerified: false,
    color: ["#9b8cff", "#62d6a7", "#ffb86b", "#ff7d91", "#7dc8ff"][Math.floor(Math.random() * 5)],
    input: { up: false, down: false, left: false, right: false }
  };
  players.set(id, player);
  send(ws, { type: "welcome", id, room: "ILHA", maxPlayers: MAX_PLAYERS, world: WORLD, modes: MODES, races: RACES, classes: CLASSES });

  ws.on("message", raw => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }
    if (!msg || typeof msg.type !== "string") return;
    if (msg.type === "join") {
      const code = String(msg.room || "ILHA").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8) || "ILHA";
      const mode = MODES[msg.mode] ? msg.mode : "classic";
      const room = roomFor(code, mode);
      const current = [...players.values()].filter(p => p.id !== id && p.room === room.key);
      const limit = MODES[mode].maxPlayers;
      if (current.length >= limit) return send(ws, { type: "error", message: `Essa sala do modo ${MODES[mode].label} está cheia (máximo ${limit}).` });
      const teamSize = MODES[mode].teamSize;
      const teamCounts = new Map();
      current.forEach(p=>teamCounts.set(p.teamId,(teamCounts.get(p.teamId)||0)+1));
      let teamId = 0;
      while ((teamCounts.get(teamId)||0) >= teamSize) teamId++;
      if (!room.teamSpawns.has(teamId)) pickSpawn(room, teamId);
      const spawn = room.teamSpawns.get(teamId);
      const teamSlot = teamCounts.get(teamId)||0;
      player.room = room.key; player.mode = mode; player.name = safeName(msg.name); player.teamId = teamId;
      player.race = RACES.includes(msg.race) ? msg.race : "Humano";
      player.playerClass = CLASSES.includes(msg.playerClass) ? msg.playerClass : "Guerreiro";
      player.city = spawn.city; player.x = spawn.x + (teamSlot - (teamSize-1)/2) * 24; player.y = spawn.y + (teamSlot % 2 ? 20 : -20);
      player.eliminated = false;
      send(ws, { type: "joined", room: code, mode, modeLabel: MODES[mode].label, city: player.city, teamId, id, maxPlayers: limit, race: player.race, playerClass: player.playerClass });
      broadcastRoom(room);
    } else if (msg.type === "input") {
      for (const k of ["up", "down", "left", "right"]) player.input[k] = !!msg[k];
      player.crouching = !!msg.crouching;
    } else if (msg.type === "chat") {
      if (!player.room) return;
      const text = String(msg.text||"").replace(/[<>]/g,"").trim().slice(0,180);
      if (!text || Date.now()-(player.lastChat||0)<900) return;
      player.lastChat=Date.now();
      const room=rooms.get(player.room); if(!room)return;
      const channel=msg.channel==="team"?"team":"global";
      for(const target of players.values()) if(target.room===player.room && (channel==="global"||target.teamId===player.teamId)) send(target.ws,{type:"chat",channel,from:player.name,teamId:player.teamId,text});
    } else if (msg.type === "action") {
      const room = rooms.get(player.room) || roomFor("ILHA", player.mode);
      if (player.eliminated) return send(ws,{type:"notice",text:"Você foi eliminado desta rodada."});
      if (msg.action === "attack") {
        const now=Date.now(); if(now-(player.lastAttack||0)<650)return; player.lastAttack=now;
        let targets=[...players.values()].filter(t=>t.room===player.room&&t.id!==player.id&&t.teamId!==player.teamId&&!t.eliminated&&Math.hypot(t.x-player.x,t.y-player.y)<76);
        targets.sort((a,b)=>Math.hypot(a.x-player.x,a.y-player.y)-Math.hypot(b.x-player.x,b.y-player.y));
        const target=targets[0];
        if(!target)return send(ws,{type:"notice",text:"Nenhum inimigo ao alcance."});
        let damage=player.playerClass==="Guerreiro"?28:player.playerClass==="Assassino"?25:player.playerClass==="Arqueiro"?24:22;
        if(player.skillBoostUntil&&player.skillBoostUntil>Date.now())damage+=10;
        if(RACE_WEAKNESS[player.race]===target.race)damage+=8;
        if(target.crouching && target.playerClass==="Guerreiro")damage=Math.ceil(damage*0.6);
        target.hp=Math.max(0,target.hp-damage); target.lastDamagedBy=player.id;
        send(ws,{type:"notice",text:`Você acertou ${target.name} (${damage} de dano).`});
        if(target.hp<=0){
          if(room.mode==="arena4v4"){target.eliminated=true;target.input={up:false,down:false,left:false,right:false};}
          else {target.hp=200;target.x=(room.teamSpawns.get(target.teamId)||{x:1600,y:1100}).x;target.y=(room.teamSpawns.get(target.teamId)||{x:1600,y:1100}).y;}
          const reward=room.mode==="ranked"?rankedKillReward(player.rankedPoints):0;
          if(room.mode==="ranked"){player.rankedPoints+=reward;target.rankedPoints=Math.max(0,target.rankedPoints-5);}
          if(target.hunterDevices>0){player.hunterDevices+=target.hunterDevices;target.hunterDevices=0;send(player.ws,{type:"notice",text:"Você saqueou o Olho do Caçador do inimigo."});}
          send(player.ws,{type:"notice",text:`Eliminação de ${target.name}! ${room.mode==="ranked"?`+${reward} pontos de ranque.`:""}`});
          send(target.ws,{type:"notice",text:`Você foi derrubado por ${player.name}.`});
          checkArenaRound(room);
        }
        broadcastRoom(room);
      } else if (msg.action === "pickupHunter") {
        if(room.mode==="arena4v4")return;
        const item=room.hunterItems.find(i=>!i.taken&&Math.hypot(i.x-player.x,i.y-player.y)<65);
        if(!item)return send(ws,{type:"notice",text:"Nenhum Olho do Caçador próximo."});
        item.taken=true;player.hunterDevices++;send(ws,{type:"notice",text:"Olho do Caçador coletado! Use-o para revelar inimigos."});broadcastRoom(room);
      } else if (msg.action === "skill") {
        const now=Date.now();
        if(now-(player.lastSkill||0)<6000)return send(ws,{type:"notice",text:"Habilidade recarregando."});
        if(player.ep<40)return send(ws,{type:"notice",text:"EP insuficiente: habilidade custa 40."});
        player.ep-=40;player.lastSkill=now;
        const teammates=[...players.values()].filter(t=>t.room===player.room&&t.teamId===player.teamId&&!t.eliminated&&Math.hypot(t.x-player.x,t.y-player.y)<190);
        const enemies=[...players.values()].filter(t=>t.room===player.room&&t.teamId!==player.teamId&&!t.eliminated&&Math.hypot(t.x-player.x,t.y-player.y)<190);
        if(player.playerClass==="Curandeiro"||player.playerClass==="Druida"){
          for(const t of (player.playerClass==="Druida"?[player]:teammates))t.hp=Math.min(200,t.hp+(player.playerClass==="Druida"?55:35));
          send(ws,{type:"notice",text:player.playerClass==="Druida"?"Raízes vitais: você recuperou 55 de vida.":"Cura em área: aliados próximos recuperaram vida."});
        } else if(player.playerClass==="Guerreiro"){
          player.hp=Math.min(200,player.hp+20);player.skillBoostUntil=now+3500;
          send(ws,{type:"notice",text:"Ímpeto do Guerreiro: +20 de vida e força temporária."});
        } else {
          const damage=player.playerClass==="Mago"?42:player.playerClass==="Assassino"?36:30;
          for(const t of enemies){let d=damage;if(t.crouching&&t.playerClass==="Guerreiro")d=Math.ceil(d*.6);t.hp=Math.max(0,t.hp-d);t.lastDamagedBy=player.id;if(t.hp===0){if(room.mode==="arena4v4")t.eliminated=true;else{t.hp=200;const sp=room.teamSpawns.get(t.teamId);if(sp){t.x=sp.x;t.y=sp.y;}}if(room.mode==="ranked"){player.rankedPoints+=rankedKillReward(player.rankedPoints);t.rankedPoints=Math.max(0,t.rankedPoints-5);}if(t.hunterDevices>0){player.hunterDevices+=t.hunterDevices;t.hunterDevices=0;}send(ws,{type:"notice",text:`Habilidade acertou ${t.name}!`});}}
          if(player.playerClass==="Mago")send(ws,{type:"notice",text:"Explosão arcana lançada."});else if(player.playerClass==="Arqueiro")send(ws,{type:"notice",text:"Rajada precisa disparada."});else send(ws,{type:"notice",text:"Ataque especial executado."});
          checkArenaRound(room);
        }
        broadcastRoom(room);
      } else if (msg.action === "hunter") {
        if(player.hunterDevices<=0)return send(ws,{type:"notice",text:"Você não tem Olho do Caçador."});
        player.hunterDevices--;
        const enemies=[...players.values()].filter(t=>t.room===player.room&&t.teamId!==player.teamId&&!t.eliminated).map(t=>({name:t.name,x:t.x,y:t.y,teamId:t.teamId}));
        send(ws,{type:"tracking",enemies}); send(ws,{type:"notice",text:"Olho do Caçador ativado e consumido."});
      } else if (msg.action === "gather") {
        // Resource points are generated near players, server validates proximity and cooldown.
        const now = Date.now();
        if (now - (player.lastGather || 0) < 650) return;
        player.lastGather = now;
        const roll = Math.random();
        if (roll < 0.55) { player.wood += 1; room.wood += 1; send(ws, { type: "notice", text: "Você coletou 1 madeira." }); }
        else { player.berries += 1; room.berries += 1; send(ws, { type: "notice", text: "Você encontrou 1 fruta." }); }
      } else if (msg.action === "eat") {
        if (player.berries > 0 && player.hunger < 100) {
          player.berries--; player.hunger = Math.min(100, player.hunger + 35);
          send(ws, { type: "notice", text: "Você comeu uma fruta. Fome recuperada!" });
        } else send(ws, { type: "notice", text: player.berries ? "Sua fome já está cheia." : "Você não tem frutas." });
      } else if (msg.action === "campfire") {
        if (player.wood >= 5) {
          player.wood -= 5; room.wood = Math.max(0, room.wood - 5);
          room.night = false; room.day += 1; room.lastDayChange = Date.now();
          for (const p of players.values()) if (p.room === player.room) p.hp = Math.min(200, p.hp + 15);
          send(ws, { type: "notice", text: "Fogueira comunitária acesa! Todos recuperaram vida." });
          broadcastRoom(room);
        } else send(ws, { type: "notice", text: "Você precisa de 5 madeiras para acender a fogueira." });
      }
    }
  });
  ws.on("close", () => { const oldRoom = rooms.get(player.room); players.delete(id); if (oldRoom) { checkArenaRound(oldRoom); broadcastRoom(oldRoom); } });
  ws.on("error", () => {});
});

function broadcastRoom(room) {
  const state = JSON.stringify(publicState(room));
  for (const p of players.values()) if (p.room === room.key && p.ws.readyState === WebSocket.OPEN) p.ws.send(state);
}
setInterval(() => {
  const now = Date.now();
  for (const p of players.values()) {
    if (p.eliminated) continue;
    const speed = p.crouching ? 2.5 : 4.2;
    let dx = (p.input.right ? 1 : 0) - (p.input.left ? 1 : 0);
    let dy = (p.input.down ? 1 : 0) - (p.input.up ? 1 : 0);
    if (dx && dy) { dx *= 0.7071; dy *= 0.7071; }
    const activeRoom = rooms.get(p.room);
    const map = activeRoom && activeRoom.mode === "arena4v4" ? {width: 1200, height: 900} : WORLD;
    p.x = clamp(p.x + dx * speed, 22, map.width - 22);
    p.y = clamp(p.y + dy * speed, 22, map.height - 22);
    if(now-(p.lastEpTick||now)>1000){p.lastEpTick=now;p.ep=Math.min(200,p.ep+2);}
    if (now - (p.lastHungerTick || now) > 12000 && p.mode !== "arena4v4") {
      p.lastHungerTick = now;
      p.hunger = Math.max(0, p.hunger - 1);
      if (p.hunger === 0) p.hp = Math.max(0, p.hp - 2);
      if (p.hp === 0) { p.hp = 200; p.hunger = 60; const room = rooms.get(p.room); const spawn = room && room.teamSpawns.get(p.teamId); p.x = spawn ? spawn.x : 1600; p.y = spawn ? spawn.y : 1100; }
    }
  }
  for (const room of rooms.values()) broadcastRoom(room);
}, TICK_MS);

server.listen(PORT, "0.0.0.0", () => console.log(`Ilha Coop rodando na porta ${PORT}`));